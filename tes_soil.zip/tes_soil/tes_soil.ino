/**
 * ====================================================================================
 * PROJECT TITEN - SISTEM PERINGATAN DINI BENCANA (MAGE 12)
 * File: tes_soil.ino
 * Target Board: ESP32 DevKit Classic V1 (ESP-WROOM-32 30-Pin / 36-Pin)
 * Sensor: Capacitive Soil Moisture Sensor (v1.2 / v2.0)
 * ====================================================================================
 * 
 * PINOUT KONEKSI:
 *  - VCC sensor  -> Pin 3V3 (3.3V) ESP32 (Disarankan 3.3V agar output tegangan aman untuk ADC)
 *  - GND sensor  -> Pin GND ESP32
 *  - AOUT sensor -> Pin GPIO 34 (ADC1_CH6 - Input Only)
 * 
 * CATATAN PENTING ADC ESP32:
 *  - GPIO 34 adalah pin ADC1, sehingga aman digunakan bersamaan dengan WiFi/LoRa
 *    (tidak konflik seperti ADC2).
 *  - Resolusi default ADC ESP32 adalah 12-bit (0 s.d 4095).
 * ====================================================================================
 */

#include <Arduino.h>

// ======================= KONFIGURASI PIN & ADC =======================
const int PIN_SOIL = 34;            // GPIO 34 (ADC1_CH6) ESP32 DevKit Classic V1
const int JUMLAH_SAMPEL = 20;       // Multi-sampling untuk meredam noise pembacaan ADC

// ======================= NILAI KALIBRASI =======================
// Lakukan kalibrasi terlebih dahulu:
// 1. Catat nilai RAW saat probe kering di udara bebas -> masukkan ke SOIL_ADC_DRY
// 2. Catat nilai RAW saat probe dicelupkan ke segelas air -> masukkan ke SOIL_ADC_WET
// Catatan: Pada sensor kapasitif, udara kering = nilai ADC tinggi (~3000-3300),
//          dan air basah = nilai ADC rendah (~1200-1500).
int SOIL_ADC_DRY = 3100;            // Nilai saat probe di udara bebas (Kering = 0%)
int SOIL_ADC_WET = 1300;            // Nilai saat probe tercelup air (Basah = 100%)

// ======================= PROTOTIPE FUNGSI =======================
int bacaAdcRataRata(int pin, int count);
int hitungPersentase(int rawValue, int dryValue, int wetValue);
const char* evaluasiStatusTanah(int persen);
void tampilkanInfoBoot();

// ======================= SETUP =======================
void setup() {
  Serial.begin(115200);
  delay(1000); // Waktu stabilisasi Serial

  // Atur konfigurasi ADC ESP32
  analogReadResolution(12);             // 12-bit resolution (0 - 4095)
  analogSetAttenuation(ADC_11db);       // 0 - 3.3V input range

  tampilkanInfoBoot();
}

// ======================= LOOP UTAMA =======================
void loop() {
  // 1. Ambil data analog dengan multi-sampling (smoothing)
  int rawAdc = bacaAdcRataRata(PIN_SOIL, JUMLAH_SAMPEL);

  // 2. Hitung perkiraan tegangan analog (Volt)
  float voltage = (rawAdc / 4095.0f) * 3.3f;

  // 3. Konversi nilai ADC ke persentase kelembapan (0 - 100%)
  int kelembapanPersen = hitungPersentase(rawAdc, SOIL_ADC_DRY, SOIL_ADC_WET);

  // 4. Evaluasi kondisi kelembapan tanah
  const char* statusTanah = evaluasiStatusTanah(kelembapanPersen);

  // 5. Cetak laporan ke Serial Monitor
  Serial.println("---------------------------------------------------------");
  Serial.print("[SOIL] ADC Raw: ");
  Serial.print(rawAdc);
  Serial.print(" | Tegangan: ");
  Serial.print(voltage, 2);
  Serial.print(" V | Kelembapan: ");
  Serial.print(kelembapanPersen);
  Serial.print("% | Status: ");
  Serial.println(statusTanah);

  // Tips: Format ringkas untuk Serial Plotter (uncomment jika ingin melihat grafik)
  // Serial.print("Raw:"); Serial.print(rawAdc);
  // Serial.print(",Kelembapan_Pct:"); Serial.println(kelembapanPersen);

  delay(1000); // Update setiap 1 detik
}

// ======================= IMPLEMENTASI FUNGSI =======================

/**
 * Membaca ADC beberapa kali lalu mengambil rata-ratanya untuk meredam noise.
 */
int bacaAdcRataRata(int pin, int count) {
  long total = 0;
  for (int i = 0; i < count; i++) {
    total += analogRead(pin);
    delayMicroseconds(500);
  }
  return (int)(total / count);
}

/**
 * Mengonversi nilai ADC mentah menjadi persentase kelembapan 0 - 100%.
 */
int hitungPersentase(int rawValue, int dryValue, int wetValue) {
  // Sensor kapasitif terbalik: Nilai tinggi = Kering (0%), Nilai rendah = Basah (100%)
  int pct = map(rawValue, dryValue, wetValue, 0, 100);
  return constrain(pct, 0, 100);
}

/**
 * Menentukan kategori kelembapan tanah berdasarkan persentase.
 */
const char* evaluasiStatusTanah(int persen) {
  if (persen < 25) {
    return "KERING (Dry)";
  } else if (persen <= 75) {
    return "LEMBAP OPTIMAL (Moist)";
  } else {
    return "BASAH JENUH (Wet / Rawan Longsor)";
  }
}

/**
 * Menampilkan panduan dan informasi awal saat boot ESP32.
 */
void tampilkanInfoBoot() {
  Serial.println("\n========================================================");
  Serial.println("     TITEN - PENGUJIAN SOIL MOISTURE SENSOR             ");
  Serial.println("     Board: ESP32 DevKit Classic V1 | Pin: GPIO 34      ");
  Serial.println("========================================================");
  Serial.println("PANDUAN KALIBRASI CEPAT:");
  Serial.println("1. Angkat sensor di udara terbuka, catat nilai 'ADC Raw'");
  Serial.println("   -> Ubah konstanta 'SOIL_ADC_DRY' dengan nilai tersebut.");
  Serial.println("2. Celupkan probe sensor ke air hingga batas garis putih");
  Serial.println("   -> Ubah konstanta 'SOIL_ADC_WET' dengan nilai tersebut.");
  Serial.println("========================================================\n");
}
