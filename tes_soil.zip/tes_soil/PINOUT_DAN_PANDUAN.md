# PANDUAN PINOUT & PENGUJIAN SOIL MOISTURE SENSOR
**Project TITEN - Sistem Peringatan Dini Bencana (MAGE 12 - ITS)**  
**Board Acuan Pengujian**: ESP32 DevKit Classic V1 (ESP-WROOM-32 30-Pin / 36-Pin)  
**Sensor**: Capacitive Soil Moisture Sensor (v1.2 / v2.0)

---

## 1. Tabel Pinout Koneksi Sensor ke ESP32 Classic V1

| Pin Sensor Tanah | Pin ESP32 DevKit Classic V1 | Warna Kabel (Standar) | Keterangan Teknis |
| :--- | :--- | :--- | :--- |
| **VCC** | **3V3 (3.3V)** | Merah | Disarankan 3.3V agar tegangan output sensor tidak melebihi batas aman ADC ESP32 (3.3V) |
| **GND** | **GND** | Hitam | Ground bersama (*Common Ground*) |
| **AOUT** (Analog Out) | **GPIO 34** | Kuning / Biru | Jalur **ADC1_CH6** (Input Only, tanpa internal pull-up/pull-down, bebas interferensi WiFi) |

> [!TIP]
> **Opsi Pin ADC Cadangan:**
> Jika GPIO 34 sedang terpakai untuk komponen lain, Anda dapat menggunakan pin **ADC1** lainnya pada ESP32 Classic:
> - **GPIO 32** (`ADC1_CH4`)
> - **GPIO 33** (`ADC1_CH5`)
> - **GPIO 35** (`ADC1_CH7`)
> - **GPIO 36 / VP** (`ADC1_CH0`)
> 
> *(Jangan gunakan pin ADC2 seperti GPIO 0, 2, 4, 12, 13, 14, 15, 25, 26, 27 jika nantinya mengaktifkan WiFi/Bluetooth, karena ADC2 akan dinonaktifkan oleh driver wireless ESP32).*

---

## 2. Diagram Skema Pengkabelan (Wiring)

```
      +----------------------------------------+
      |  CAPACITIVE SOIL MOISTURE SENSOR       |
      |                                        |
      |   [ VCC ]     [ GND ]       [ AOUT ]   |
      +------+-----------+--------------+------+
             |           |              |
             | 3.3V      | GND          | Analog Signal
             v           v              v
      +------+-----------+--------------+------+
      |   3V3           GND          GPIO 34   |
      |                                        |
      |         ESP32 DEVKIT CLASSIC V1        |
      |              (ESP-WROOM-32)            |
      |                 [ USB ]                |
      +----------------------------------------+
```

---

## 3. Langkah Pengujian & Kalibrasi Nilai Sensor

Karakteristik **Capacitive Soil Sensor** memiliki logika output **terbalik**:
- **Udara Terbuka / Kering**: Kapasitansi rendah $\rightarrow$ Nilai ADC **TINGGI** ($\approx 2800 - 3300$)
- **Air Basah Jenuh**: Kapasitansi tinggi $\rightarrow$ Nilai ADC **RENDAH** ($\approx 1200 - 1600$)

### Prosedur Kalibrasi:
1. **Langkah 1 (Uji Kering / 0%)**:
   - Biarkan lempeng sensor di udara terbuka (kering dan bersih).
   - Buka **Serial Monitor** pada baudrate **115200**.
   - Catat nilai `ADC Raw` yang tampil (misal: `3120`).
   - Masukkan nilai ini ke variabel `SOIL_ADC_DRY` pada file [tes_soil.ino](tes_soil.ino).

2. **Langkah 2 (Uji Basah Jenuh / 100%)**:
   - Siapkan segelas air.
   - Celupkan lempeng sensor ke dalam air **hanya sampai batas garis putih** (*waterline / warning line*).
   - **PERINGATAN**: Jangan sampai komponen elektronik di bagian kepala atas sensor terendam air!
   - Catat nilai `ADC Raw` yang tampil saat tercelup (misal: `1340`).
   - Masukkan nilai ini ke variabel `SOIL_ADC_WET` pada file [tes_soil.ino](tes_soil.ino).

3. **Langkah 3 (Pengujian Lapangan)**:
   - Tancapkan sensor ke media tanah.
   - Periksa persentase yang terbaca:
     - `< 25%` : **KERING (Dry)**
     - `25% - 75%` : **LEMBAP OPTIMAL (Moist)**
     - `> 75%` : **BASAH JENUH (Wet / Rawan Longsor)**

---

## 4. Troubleshooting Cepat

- **Nilai ADC konstan 4095**:
  - Kabel AOUT terlepas, atau sensor diberi daya 5V sehingga sinyal melebihi batas tegangan referensi ADC ESP32. Pindahkan VCC ke pin 3V3.
- **Nilai ADC konstan 0**:
  - Kabel AOUT menyentuh GND, atau pin ADC yang digunakan salah didefinisikan.
- **Nilai pembacaan berfluktuasi liar**:
  - Pasang kapasitor $100\text{ nF}$ antara pin `AOUT` dan `GND` sensor, atau gunakan fitur *smoothing* `JUMLAH_SAMPEL` yang sudah disediakan pada file [tes_soil.ino](tes_soil.ino).
